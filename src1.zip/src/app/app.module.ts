import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListbooksComponent } from './listbooks/listbooks.component';
import { AddbookComponent } from './addbook/addbook.component';
import { HttpClient,HttpClientModule } from '@angular/common/http';
import { EserviceService } from './eservice.service';
import { UpdateComponent } from './update/update.component';

@NgModule({
  declarations: [
    AppComponent,
    ListbooksComponent,
    AddbookComponent,
    UpdateComponent,

     
  ],
  imports: [FormsModule,ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,HttpClientModule
  ],
  providers: [HttpClient,EserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
