import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class EserviceService {
  http:HttpClient;
  employees:Employee[]=[]; // array to store Employee components
  constructor(http:HttpClient){ // there is a dependency on http, so @Injectable required
      this.http=http;
  }
  fetched:boolean=false;
  fetchEmployees(){
       this.http.get('./assets/employees.json').subscribe(
         data=>{
           if(!this.fetched){  
             this.convert(data); // send json to convert function
             this.fetched=true;
           }
         });        
      }
      getEmployees():Employee[]{
        return this.employees;
 }
 convert(data:any){ // convert json into Employee components
    for(let o of data){
      let e=new Employee(o.bookid,o.bookname,o.bookcost,o.author);
      this.employees.push(e); // store in employees array
    }
 }
 delete(bookid:number){
   let foundIndex:number=-1;
   for(let i=0;i<this.employees.length;i++){
      let e=this.employees[i];
      if(bookid==e.bookid){
        foundIndex=i ;
        break;
      }
  }
  this.employees.splice(foundIndex,1);  
}
update(bid:any)
{
   for(let i=0;i<this.employees.length;i++){
      let e=this.employees[i];
      if(bid.bookid==e.bookid){
        //console.log(bookid.bookname);
        this.employees.splice(i,1);  
        this.employees.push(bid);
        //console.log(e.bookname);
        //console.log(e.bookcost);
        //console.log(e.author);
        break;
      }
  }
}
add(e:Employee){
    this.employees.push(e);
    console.log(e.bookid);
}
}
export class Employee{
  bookid:number;
 bookname:string;
bookcost:number;
author:string;
  constructor(bookid:number,bookname:string,bookcost:number,author:string){
    this.bookid=bookid;
    this.bookname=bookname;
    this.bookcost=bookcost;
    this.author=author;
 }
}