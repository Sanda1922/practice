import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListbooksComponent } from './listbooks/listbooks.component';
import { AddbookComponent } from './addbook/addbook.component';
import { UpdateComponent } from './update/update.component';


const routes: Routes = [
  {path:'',component:ListbooksComponent},
{path:'app-listbooks',component:ListbooksComponent},
{path:'app-addbook',component:AddbookComponent},
{path:'app-update',component:UpdateComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
