import { Component, OnInit } from '@angular/core';
import { EserviceService, Employee } from '../eservice.service';
import { Routes,RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {
service:EserviceService;
  constructor(service:EserviceService,private router: Router) { 
this.service=service;
  }

  ngOnInit(): void {
  }
  add(e:Employee){
 // let x={id:e.id,name:e.name};
  // this.service.add(x);

    this.service.add(e);
 this.router.navigate(['app-listbooks']);
  }

}
