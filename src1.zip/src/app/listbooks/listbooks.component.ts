import { Component, OnInit } from '@angular/core';
import { EserviceService, Employee } from '../eservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-listbooks',
  templateUrl: './listbooks.component.html',
  styleUrls: ['./listbooks.component.css']
})
export class ListbooksComponent implements OnInit {
  service:EserviceService;
  constructor(service:EserviceService,public router:Router) {
    this.service=service;
   }
   employees:Employee[]=[]
  ngOnInit(): void {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
    
  }
delete(bookid:number)
{
  this.service.delete(bookid);
}
update(bookid:number)
{
  this.router.navigate(['app-update']);
}
}
